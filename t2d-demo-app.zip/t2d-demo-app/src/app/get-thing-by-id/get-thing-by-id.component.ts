import { Component, OnInit } from '@angular/core';
import {T2dapiService} from '../t2dapi.service';


@Component({
  selector: 'app-get-thing-by-id',
  templateUrl: './get-thing-by-id.component.html',
  styleUrls: ['./get-thing-by-id.component.css']
})
export class GetThingByIdComponent implements OnInit {

  thingID:string="inv1.sovelto.fi/T2";
  response;
  
  constructor(private t2dapi: T2dapiService) { }

  ngOnInit() {
  }
  getThing(){
    this.t2dapi.getThingById(this.thingID)
    .subscribe(response=>{this.response=response
  console.dir(response);
  });
  

  }

}
