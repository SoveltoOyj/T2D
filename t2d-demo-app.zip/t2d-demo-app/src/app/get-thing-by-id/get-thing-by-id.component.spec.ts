import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GetThingByIdComponent } from './get-thing-by-id.component';

describe('GetThingByIdComponent', () => {
  let component: GetThingByIdComponent;
  let fixture: ComponentFixture<GetThingByIdComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GetThingByIdComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GetThingByIdComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
