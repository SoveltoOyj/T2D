import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EnumNamesValuesComponent } from './enum-names-values.component';

describe('EnumNamesValuesComponent', () => {
  let component: EnumNamesValuesComponent;
  let fixture: ComponentFixture<EnumNamesValuesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EnumNamesValuesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EnumNamesValuesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
