import { Component, OnInit } from '@angular/core';
import {T2dapiService} from '../t2dapi.service';
import { Observable } from 'rxjs/Observable';

@Component({
  selector: 'app-enum-names-values',
  templateUrl: './enum-names-values.component.html',
  styleUrls: ['./enum-names-values.component.css']
})
export class EnumNamesValuesComponent implements OnInit {
  enumNames:Observable<string[]>;
   enumValues:Observable<string[]>;
  selectedName;
  constructor(private t2dapi: T2dapiService) { }

  ngOnInit() {
    this.enumNames=this.t2dapi.getEnumNames();
    //.subscribe(response=>this.enumNames=response);
  }
  onSelect(name){
    this.selectedName=name;
    this.enumValues=this.t2dapi.getEnumValues(this.selectedName);
  }

}
