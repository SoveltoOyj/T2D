import { Injectable } from '@angular/core';
import { Http, Headers, RequestOptions, Response }       from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/map';

@Injectable()
export class T2dapiService {

 apiUrl:string="https://thingtodata.azurewebsites.net/api/"
  constructor(private http:Http) { }

  public getThingById(thingid:string){
    let headers = new Headers({ 'Content-Type': 'application/json' });
    let options = new RequestOptions({ headers: headers });
      let params= { 
    "attributes": [
      "Title", 
  "Description", 
  "IsGpsPublic", 
  "GpsLocation"  
    ], 
    "session": "00000000-0000-0000-0000-000000000001",  
    "thingId": thingid, 
    "role": "Omnipotent" 
  };

    return this.http.post(this.apiUrl+'inventory/Core/GetAttributes', params, options)
       .map(response=>response.json())
        .catch(this.handleError);
  }
  public getEnumNames(){
    return this.http.get(this.apiUrl+'MetaData/EnumNames')
    .map(response=>response.json())
    .catch(this.handleError);
  }
 public getEnumValues(name:string){
    return this.http.get(this.apiUrl+'MetaData/EnumValues?enumName='+name)
    .map(response=>response.json())
    .catch(this.handleError);
 }
 public searchByGeolocation(latitude, longitude, distance){
      let headers = new Headers({ 'Content-Type': 'application/json' });
      let options = new RequestOptions({ headers: headers });
      distance = distance || 500;
      let params ={
  "gpsLocation": {
    "latitude": latitude,
    "longitude": longitude
  },
  "distance": distance,
  "currentPage": 0,
  "pageSize": 10
}
  return this.http.post(this.apiUrl+'inventory/Core/GetNearbyPublicLocationThings', params, options)
       .map(response=>response.json())
        .catch(this.handleError);
 }

public getServices(thingid:string){
  let headers = new Headers({ 'Content-Type': 'application/json' });
    let options = new RequestOptions({ headers: headers });
    let params= { 
  
   "session": "00000000-0000-0000-0000-000000000002",  
   "thingId": thingid, 
   "role": "Anonymous" 
 };
    return this.http.post(this.apiUrl+'inventory/Service/GetServices', params, options)
       .map(response=>response.json())
        .catch(this.handleError);
}

public doServiceRequest(thingid:string, servicename:string){
   let headers = new Headers({ 'Content-Type': 'application/json' });
    let options = new RequestOptions({ headers: headers });
    let params= { 
    "service":servicename,
   "session": "00000000-0000-0000-0000-000000000002",  
   "thingId": thingid, 
   "role": "Anonymous" 
 };
 return this.http.post(this.apiUrl+'inventory/Service/ServiceRequest', params, options)
       .map(response=>response)
        .catch(this.handleError);
}

public getServiceStatuses(thingid:string){
  let headers = new Headers({ 'Content-Type': 'application/json' });
    let options = new RequestOptions({ headers: headers });
    let params= { 
   "session": "00000000-0000-0000-0000-000000000002",  
   "thingId": thingid, 
   "role": "Anonymous" 
 };
    return this.http.post(this.apiUrl+'inventory/Service/GetServiceStatus', params, options)
       .map(response=>response.json())
        .catch(this.handleError);
}

public getActionStatuses(thingid:string){
  let headers = new Headers({ 'Content-Type': 'application/json' });
    let options = new RequestOptions({ headers: headers });
    let params= { 
   "session": "00000000-0000-0000-0000-000000000001",  
   "thingId":thingid,
   "role": "Omnipotent" 
 };
    return this.http.post(this.apiUrl+'inventory/Service/GetActionStatuses', params, options)
       .map(response=>response.json())
        .catch(this.handleError);
}
public getActionStatus(actionid:string, thingid:string){
  let headers = new Headers({ 'Content-Type': 'application/json' });
    let options = new RequestOptions({ headers: headers });
    let params= { 
   "session": "00000000-0000-0000-0000-000000000001",  
   "actionId": actionid, 
   "thingId":thingid,
   "role": "Omnipotent" 
 };
    return this.http.post(this.apiUrl+'inventory/Service/GetActionStatus', params, options)
       .map(response=>response.json())
        .catch(this.handleError);
}
private handleError (error: Response | any) {
  // In a real world app, you might use a remote logging infrastructure
  let errMsg: string;
  if (error instanceof Response) {
    const body = error.json() || '';
    const err = body.error || JSON.stringify(body);
    errMsg = `${error.status} - ${error.statusText || ''} ${err}`;
  } else {
    errMsg = error.message ? error.message : error.toString();
  }
  console.error(errMsg);
  return Observable.throw(errMsg);
}
  
}
