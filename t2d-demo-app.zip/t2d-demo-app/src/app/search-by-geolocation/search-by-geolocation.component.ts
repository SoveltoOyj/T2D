import { Component, OnInit } from '@angular/core';
import {T2dapiService} from '../t2dapi.service';

@Component({
  selector: 'app-search-by-geolocation',
  templateUrl: './search-by-geolocation.component.html',
  styleUrls: ['./search-by-geolocation.component.css']
})
export class SearchByGeolocationComponent implements OnInit {
 //Pasila:
  latitude=60.2009;
  longitude= 24.9343; 

  distance=10000;
  response;
  constructor(private t2dapi: T2dapiService) { }

  ngOnInit() {
    
  }
  search(){
    this.t2dapi.searchByGeolocation(this.latitude, this.longitude, this.distance)
    .subscribe(response=>{this.response=response
  console.dir(response);
  });
}
setPosition(position){
      this.latitude = position.coords.latitude;
      this.longitude=position.coords.longitude;
      console.log(position.coords);
      }
 locateMe(){
   navigator.geolocation.getCurrentPosition(this.setPosition.bind(this), function (err){
     console.dir(err);
   })
 }
}
