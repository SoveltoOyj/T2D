import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SearchByGeolocationComponent } from './search-by-geolocation.component';

describe('SearchByGeolocationComponent', () => {
  let component: SearchByGeolocationComponent;
  let fixture: ComponentFixture<SearchByGeolocationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SearchByGeolocationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SearchByGeolocationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
