import { Component, OnInit } from '@angular/core';
import {T2dapiService} from '../t2dapi.service';

@Component({
  selector: 'app-actions',
  templateUrl: './actions.component.html',
  styleUrls: ['./actions.component.css']
})
export class ActionsComponent implements OnInit {
  thingID:string="inv1.sovelto.fi/M100";
  actions;
  selectedAction;
  response;
  constructor(private t2dapi:T2dapiService) { }

  ngOnInit() {
  }
    getActions(){
      this.t2dapi.getActionStatuses(this.thingID)
    .subscribe(response=>{
      this.actions=response.statuses;
      this.response=response;
  console.dir(response);
});
}

onSelect(action){
  this.selectedAction=action;
  this.t2dapi.getActionStatus(this.selectedAction.actionId, this.thingID)
  .subscribe(response=>{
    this.response=response;
    console.dir(response);
  })
}
}
