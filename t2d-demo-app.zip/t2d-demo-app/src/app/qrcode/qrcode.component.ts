import { Component, OnInit, ViewChild, ViewEncapsulation } from '@angular/core';
import {QrScannerComponent} from 'angular2-qrscanner'
import {T2dapiService} from '../t2dapi.service';

@Component({
  selector: 'app-qrcode',
  templateUrl: './qrcode.component.html',
  styleUrls: ['./qrcode.component.css'],
  encapsulation: ViewEncapsulation.None,
})
export class QrcodeComponent implements OnInit {
  @ViewChild(QrScannerComponent) qrScannerComponent: QrScannerComponent ;
  thingID:string="test";
  response;
  
  constructor(private t2dapi:T2dapiService) { }

  ngOnInit() {
    this.qrScannerComponent.getMediaDevices().then(devices => {
      console.log(devices);
      const videoDevices: MediaDeviceInfo[] = [];
      for (const device of devices) {
          if (device.kind.toString() === 'videoinput') {
              videoDevices.push(device);
          }
      }
      if (videoDevices.length > 0){
          let choosenDev;
          for (const dev of videoDevices){
              if (dev.label.includes('front')){
                  choosenDev = dev;
                  break;
              }
          }
          if (choosenDev) {
              this.qrScannerComponent.chooseCamera.next(choosenDev);
          } else {
              this.qrScannerComponent.chooseCamera.next(videoDevices[0]);
          }
      }
  });

  this.qrScannerComponent.capturedQr.subscribe(result => {
      console.log(result);
      this.decodedOutput(result);
  });
  }
  show(){
    
  }
  decodedOutput(uri){
    console.dir(uri);
    this.thingID=uri;
     this.t2dapi.getThingById(this.thingID)
    .subscribe(response=>{
      this.response=response;
  console.dir(response);
  })
  }

}
