import { Component, OnInit } from '@angular/core';
import {T2dapiService} from '../t2dapi.service';

@Component({
  selector: 'services-demo',
  templateUrl: './services.component.html',
  styleUrls: ['./services.component.css']
})
export class ServicesComponent implements OnInit {
  thingID:string="inv1.sovelto.fi/T2";
  selectedService:string;
  services;
  response;
  constructor(private t2dapi:T2dapiService) { }
  getServices(){
      this.t2dapi.getServices(this.thingID)
    .subscribe(response=>{this.response=response;
      this.services=response.services;
  console.dir(response);
  });
}
doServiceRequest(){
    this.t2dapi.doServiceRequest(this.thingID, this.selectedService)
    .subscribe(response=>{this.response=response;
  console.dir(response);
  });
}
onSelect (service){
  this.selectedService=service;
}
getServiceStatuses(){
   this.t2dapi.getServiceStatuses(this.thingID)
    .subscribe(response=>{this.response=response;
  console.dir(response);
  
});

}
  ngOnInit() {
  }

}
