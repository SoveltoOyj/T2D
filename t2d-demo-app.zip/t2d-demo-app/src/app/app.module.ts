import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { RouterModule } from '@angular/router';

import { NgQrScannerModule} from 'angular2-qrscanner';

import { AppComponent } from './app.component';
import { GetThingByIdComponent } from './get-thing-by-id/get-thing-by-id.component';
import { EnumNamesValuesComponent} from './enum-names-values/enum-names-values.component';
import {T2dapiService} from './t2dapi.service';
import { SearchByGeolocationComponent } from './search-by-geolocation/search-by-geolocation.component';
import { QrcodeComponent } from './qrcode/qrcode.component';
import { ServicesComponent } from './services/services.component';
import { ActionsComponent } from './actions/actions.component';

@NgModule({
  declarations: [
    AppComponent,
    GetThingByIdComponent,
    EnumNamesValuesComponent,
    SearchByGeolocationComponent,
    ServicesComponent,
    ActionsComponent,
    QrcodeComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpModule, 
    NgQrScannerModule,
     RouterModule.forRoot([
      {
        path: 'getthingbyid',
        component:GetThingByIdComponent
      }, {
        path: 'enumnamesvalues',
        component:EnumNamesValuesComponent
      },{
        path:'geolocation',
        component:SearchByGeolocationComponent
      },{
        path:'qrcode',
        component:QrcodeComponent
      },
      {
        path:'services',
        component:ServicesComponent
      },{
        path:'actions',
        component:ActionsComponent
      }
    ])
  ],
  providers: [T2dapiService],
  bootstrap: [AppComponent]
})
export class AppModule { }
